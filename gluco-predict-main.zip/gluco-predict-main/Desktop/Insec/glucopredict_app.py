import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

st.set_page_config(page_title="GlucoPredict", page_icon="🩸", layout="wide")

st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&family=Outfit:wght@300;400;500&display=swap');

  html, body, [class*="css"] {
    font-family: 'Outfit', sans-serif;
  }

  .stApp {
    background: #0d0f14;
    color: #e2e8f0;
  }

  h1, h2, h3 {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
  }

  /* ── Sidebar ── */
  div[data-testid="stSidebar"] {
    background: #111318 !important;
    border-right: 1px solid #1e2130;
    padding: 1.5rem 1rem;
  }
  div[data-testid="stSidebar"] * {
    color: #ffffff !important;
  }

  /* Section title labels */
  .section-title {
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    color: #ffffff !important;
    margin: 1.4rem 0 0.6rem 0;
    padding-bottom: 0.4rem;
    border-bottom: 1px solid #1e2130;
  }

  /* Number inputs — clean clinical look */
  div[data-testid="stNumberInput"] > label {
    font-size: 0.75rem !important;
    color: #ffffff !important;
    font-family: 'Outfit', sans-serif !important;
    font-weight: 400 !important;
    letter-spacing: 0.03em !important;
    margin-bottom: 2px !important;
  }

  div[data-testid="stNumberInput"] input {
    background: #181c26 !important;
    border: 1px solid #262d3d !important;
    border-radius: 8px !important;
    color: #e2e8f0 !important;
    font-family: 'Space Mono', monospace !important;
    font-size: 0.88rem !important;
    padding: 0.45rem 0.75rem !important;
    transition: border-color 0.2s !important;
  }
  div[data-testid="stNumberInput"] input:focus {
    border-color: #4f6ef7 !important;
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(79,110,247,0.15) !important;
  }

  /* Stepper buttons */
  div[data-testid="stNumberInput"] button {
    background: #1e2335 !important;
    border: 1px solid #262d3d !important;
    color: #6b7280 !important;
    border-radius: 6px !important;
  }
  div[data-testid="stNumberInput"] button:hover {
    background: #262d3d !important;
    color: #e2e8f0 !important;
  }

  /* Selectbox */
  div[data-testid="stSelectbox"] > label,
  div[data-testid="stRadio"] > label {
    font-size: 0.75rem !important;
    color: #ffffff !important;
    font-family: 'Outfit', sans-serif !important;
  }
  div[data-testid="stSelectbox"] > div > div {
    background: #181c26 !important;
    border: 1px solid #262d3d !important;
    border-radius: 8px !important;
    color: #e2e8f0 !important;
  }

  /* Radio buttons */
  div[data-testid="stRadio"] div[role="radiogroup"] label {
    color: #ffffff !important;
    font-size: 0.82rem !important;
  }

  /* Predict button */
  .stButton > button {
    background: linear-gradient(135deg, #4f6ef7 0%, #7c3aed 100%);
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.75rem 1.5rem !important;
    font-family: 'Syne', sans-serif !important;
    font-size: 0.9rem !important;
    font-weight: 600 !important;
    width: 100% !important;
    letter-spacing: 0.04em !important;
    margin-top: 1.5rem !important;
    transition: opacity 0.2s, transform 0.1s !important;
    box-shadow: 0 4px 20px rgba(79,110,247,0.3) !important;
  }
  .stButton > button:hover {
    opacity: 0.9 !important;
    transform: translateY(-1px) !important;
  }

  /* Result cards */
  .result-card {
    background: #111318;
    border-radius: 16px;
    padding: 1.75rem 2rem;
    margin: 0.75rem 0;
    border: 1px solid #1e2130;
  }

  .zone-label {
    font-family: 'Space Mono', monospace;
    font-size: 0.62rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: #4a5568;
    margin-bottom: 0.6rem;
  }

  .glucose-number {
    font-family: 'Space Mono', monospace;
    font-size: 4.5rem;
    font-weight: 700;
    letter-spacing: -3px;
    line-height: 1;
  }

  .unit-label {
    font-family: 'Outfit', sans-serif;
    font-size: 0.85rem;
    color: #4a5568;
    font-weight: 400;
    margin-top: 0.4rem;
  }

  .risk-badge {
    display: inline-block;
    padding: 0.35rem 1rem;
    border-radius: 99px;
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    margin-top: 1rem;
  }

  .gauge-bar {
    height: 6px;
    border-radius: 99px;
    background: #1e2130;
    overflow: hidden;
    margin: 0.75rem 0 0.5rem 0;
  }

  .metric-mini {
    background: #111318;
    border: 1px solid #1e2130;
    border-radius: 12px;
    padding: 1.1rem 1.25rem;
    text-align: center;
  }
  .metric-mini .val {
    font-family: 'Space Mono', monospace;
    font-size: 1.4rem;
    font-weight: 700;
    color: #e2e8f0;
  }
  .metric-mini .lbl {
    font-family: 'Space Mono', monospace;
    font-size: 0.6rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #4a5568;
    margin-top: 4px;
  }

  .main-header {
    border-bottom: 1px solid #1e2130;
    padding-bottom: 1.2rem;
    margin-bottom: 1.5rem;
  }

  /* Divider */
  hr {
    border-color: #1e2130 !important;
  }
</style>
""", unsafe_allow_html=True)


# ── Model training ────────────────────────────────────────────────────────────
@st.cache_resource
def load_models():
    try:
        df = pd.read_csv("GlucoBench_benchmark_dataset.csv")
        df = df[df['cgm_quality_flag'] == 1]
        cols = ['timestamp','glucose','insulin_bolus','insulin_basal','carbs',
                'heart_rate','skin_temp','gsr','sleep_stage','medication_other',
                'stress_level','alcohol','hbA1c','age','sex','weight',
                'carb_ratio','insulin_sensitivity','glucose_lag_1','glucose_lag_3',
                'glucose_lag_6','glucose_roll_mean_1h']
        dt = df[cols].dropna(subset=['glucose_lag_1','glucose_lag_3','glucose_lag_6'])
        dt = pd.get_dummies(dt, columns=['sex','sleep_stage','medication_other'], drop_first=True)
        dt['timestamp'] = pd.to_datetime(dt['timestamp'])
        dt['hour'] = dt['timestamp'].dt.hour
        dt['is_night'] = ((dt['hour'] >= 22) | (dt['hour'] < 6)).astype(int)
        dt['day_of_week'] = dt['timestamp'].dt.dayofweek
        dt['glucose_delta_5min'] = dt['glucose'] - dt['glucose_lag_1']
        dt['glucose_delta_15min'] = dt['glucose'] - dt['glucose_lag_3']
        dt['fut_glu'] = dt['glucose'].shift(-6)
        dt['hypo_30min'] = (dt['fut_glu'] < 80).astype(int)
        dt['hypogly'] = (dt['glucose'] < 80).astype(int)

        base_drop = ['glucose','timestamp','hypogly','fut_glu','hypo_30min']
        X = dt.dropna(subset=['fut_glu']).drop(base_drop, axis=1)
        feature_cols = X.columns.tolist()

        Y_reg = dt.dropna(subset=['fut_glu'])['fut_glu']
        X_reg = X
        x_train, x_test, y_train, _ = train_test_split(X_reg, Y_reg, test_size=0.2, shuffle=False)
        scaler_reg = StandardScaler()
        scaler_reg.fit(x_train)
        reg_model = LinearRegression()
        reg_model.fit(scaler_reg.transform(x_train), y_train)

        dt2 = dt.dropna(subset=['fut_glu'])
        X_cls = dt2.drop(base_drop, axis=1)
        Y_cls = dt2['hypo_30min']
        x_tr, _, y_tr, _ = train_test_split(X_cls, Y_cls, test_size=0.2, shuffle=False)
        scaler_cls = StandardScaler()
        scaler_cls.fit(x_tr)
        cls_model = LogisticRegression(class_weight={0:1,1:5}, max_iter=1000)
        cls_model.fit(scaler_cls.transform(x_tr), y_tr)

        return reg_model, cls_model, scaler_reg, scaler_cls, feature_cols, None
    except Exception as e:
        return None, None, None, None, None, str(e)


def build_input_df(vals, feature_cols):
    now = pd.Timestamp.now()
    hour = now.hour
    is_night = int((hour >= 22) or (hour < 6))
    dow = now.dayofweek

    base = {
        'insulin_bolus': vals['insulin_bolus'],
        'insulin_basal': vals['insulin_basal'],
        'carbs': vals['carbs'],
        'heart_rate': vals['heart_rate'],
        'skin_temp': vals['skin_temp'],
        'gsr': vals['gsr'],
        'stress_level': vals['stress_level'],
        'alcohol': vals['alcohol'],
        'hbA1c': vals['hbA1c'],
        'age': vals['age'],
        'weight': vals['weight'],
        'carb_ratio': vals['carb_ratio'],
        'insulin_sensitivity': vals['insulin_sensitivity'],
        'glucose_lag_1': vals['glucose_lag_1'],
        'glucose_lag_3': vals['glucose_lag_3'],
        'glucose_lag_6': vals['glucose_lag_6'],
        'glucose_roll_mean_1h': vals['glucose_roll_mean_1h'],
        'glucose_delta_5min': vals['glucose_lag_1'] - vals['glucose_lag_3'],
        'glucose_delta_15min': vals['glucose_lag_1'] - vals['glucose_lag_6'],
        'hour': hour,
        'is_night': is_night,
        'day_of_week': dow,
        'sex_M': 1 if vals['sex'] == 'Male' else 0,
        'sleep_stage_awake': 1 if vals['sleep_stage'] == 'awake' else 0,
        'sleep_stage_deep': 1 if vals['sleep_stage'] == 'deep' else 0,
        'sleep_stage_light': 1 if vals['sleep_stage'] == 'light' else 0,
        'medication_other_beta_blocker': 1 if vals['medication'] == 'beta_blocker' else 0,
        'medication_other_none': 1 if vals['medication'] == 'none' else 0,
        'medication_other_steroid': 1 if vals['medication'] == 'steroid' else 0,
    }

    row = {col: base.get(col, 0) for col in feature_cols}
    return pd.DataFrame([row])


# ── UI ─────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
  <span style="font-family:'Syne',sans-serif; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px; color:#e2e8f0;">
    Gluco<span style="color:#4f6ef7;">Predict</span>
  </span>
  <span style="font-family:'Space Mono',monospace; font-size:0.65rem; text-transform:uppercase; letter-spacing:0.15em; color:#4a5568; margin-left:1rem; vertical-align:middle;">
    30-min glucose forecast · hypoglycemia detection
  </span>
</div>
""", unsafe_allow_html=True)

reg_model, cls_model, scaler_reg, scaler_cls, feature_cols, load_err = load_models()

if load_err:
    st.error(f"⚠️ Could not load dataset: `{load_err}`")
    st.info("Make sure the CSV path in `load_models()` matches your local file path.")
    st.stop()

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="font-family:'Syne',sans-serif; font-size:1rem; font-weight:700; color:#e2e8f0; margin-bottom:0.25rem;">
      Patient Inputs
    </div>
    <div style="font-family:'Space Mono',monospace; font-size:0.6rem; color:#4a5568; text-transform:uppercase; letter-spacing:0.12em; margin-bottom:1rem;">
      Enter values manually
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<p class="section-title">Current glucose readings</p>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        glucose_lag_1 = st.number_input("5 min ago (mg/dL)", min_value=40, max_value=400, value=120, step=1)
        glucose_lag_6 = st.number_input("30 min ago (mg/dL)", min_value=40, max_value=400, value=115, step=1)
    with c2:
        glucose_lag_3 = st.number_input("15 min ago (mg/dL)", min_value=40, max_value=400, value=118, step=1)
        glucose_roll_mean_1h = st.number_input("1-hr mean (mg/dL)", min_value=40, max_value=400, value=117, step=1)

    st.markdown('<p class="section-title">Insulin & nutrition</p>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        insulin_bolus = st.number_input("Bolus (U)", min_value=0.0, max_value=20.0, value=0.0, step=0.5)
        carbs = st.number_input("Carbs (g)", min_value=0, max_value=150, value=30, step=1)
    with c2:
        insulin_basal = st.number_input("Basal (U/hr)", min_value=0.0, max_value=5.0, value=0.8, step=0.1)
        carb_ratio = st.number_input("Carb ratio", min_value=1.0, max_value=30.0, value=10.0, step=0.5)
    insulin_sensitivity = st.number_input("Insulin sensitivity", min_value=10.0, max_value=100.0, value=50.0, step=1.0)

    st.markdown('<p class="section-title">Vitals & lifestyle</p>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        heart_rate = st.number_input("Heart rate (bpm)", min_value=40, max_value=180, value=72, step=1)
        gsr = st.number_input("GSR (µS)", min_value=0.0, max_value=20.0, value=2.0, step=0.1)
    with c2:
        skin_temp = st.number_input("Skin temp (°C)", min_value=30.0, max_value=40.0, value=36.5, step=0.1)

    stress_level = st.selectbox("Stress level", [0, 1, 2, 3],
                                 format_func=lambda x: ["None","Low","Medium","High"][x])
    c1, c2 = st.columns(2)
    with c1:
        alcohol = st.selectbox("Alcohol", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes")
    with c2:
        sleep_stage = st.selectbox("Sleep stage", ["rem", "awake", "deep", "light"])

    st.markdown('<p class="section-title">Patient profile</p>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        hbA1c = st.number_input("HbA1c (%)", min_value=4.0, max_value=14.0, value=7.5, step=0.1)
        weight = st.number_input("Weight (kg)", min_value=30.0, max_value=200.0, value=75.0, step=0.5)
    with c2:
        age = st.number_input("Age", min_value=10, max_value=90, value=40, step=1)

    sex = st.radio("Sex", ["Male", "Female"], horizontal=True)
    medication = st.selectbox("Medication", ["none", "beta_blocker", "steroid", "other"])

    predict_btn = st.button("Run prediction →")


# ── Main panel ────────────────────────────────────────────────────────────────
if predict_btn:
    vals = dict(
        glucose_lag_1=glucose_lag_1, glucose_lag_3=glucose_lag_3,
        glucose_lag_6=glucose_lag_6, glucose_roll_mean_1h=glucose_roll_mean_1h,
        insulin_bolus=insulin_bolus, insulin_basal=insulin_basal, carbs=carbs,
        carb_ratio=carb_ratio, insulin_sensitivity=insulin_sensitivity,
        heart_rate=heart_rate, skin_temp=skin_temp, gsr=gsr,
        stress_level=stress_level, alcohol=alcohol, sleep_stage=sleep_stage,
        hbA1c=hbA1c, age=age, sex=sex, weight=weight, medication=medication
    )

    input_df = build_input_df(vals, feature_cols)
    pred_glucose = reg_model.predict(scaler_reg.transform(input_df))[0]
    hypo_prob = cls_model.predict_proba(scaler_cls.transform(input_df))[0][1]

    delta = pred_glucose - glucose_lag_1
    delta_str = f"{'▲' if delta >= 0 else '▼'} {abs(delta):.1f} mg/dL vs now"

    if pred_glucose < 70:
        zone, zone_color, zone_bg = "Hypoglycemia", "#f87171", "rgba(248,113,113,0.1)"
    elif pred_glucose < 80:
        zone, zone_color, zone_bg = "Low", "#fb923c", "rgba(251,146,60,0.1)"
    elif pred_glucose <= 140:
        zone, zone_color, zone_bg = "In range", "#34d399", "rgba(52,211,153,0.1)"
    elif pred_glucose <= 180:
        zone, zone_color, zone_bg = "Elevated", "#fb923c", "rgba(251,146,60,0.1)"
    else:
        zone, zone_color, zone_bg = "High", "#f87171", "rgba(248,113,113,0.1)"

    if hypo_prob < 0.25:
        risk_label, risk_color, risk_bg = "Low risk", "#34d399", "rgba(52,211,153,0.1)"
    elif hypo_prob < 0.6:
        risk_label, risk_color, risk_bg = "Moderate risk", "#fb923c", "rgba(251,146,60,0.1)"
    else:
        risk_label, risk_color, risk_bg = "High risk", "#f87171", "rgba(248,113,113,0.1)"

    col1, col2 = st.columns([3, 2])

    with col1:
        st.markdown(f"""
        <div class="result-card" style="border-left: 3px solid {zone_color};">
          <div class="zone-label">predicted glucose · 30 min</div>
          <div class="glucose-number" style="color:{zone_color};">{pred_glucose:.0f}
            <span style="font-size:1.2rem; letter-spacing:0; color:#4a5568; font-weight:400;">mg/dL</span>
          </div>
          <div class="unit-label">{delta_str}</div>
          <span class="risk-badge" style="background:{zone_bg}; color:{zone_color};">{zone}</span>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
        <div class="result-card" style="border-left: 3px solid {risk_color};">
          <div class="zone-label">hypoglycemia probability</div>
          <div class="glucose-number" style="color:{risk_color}; font-size:3.5rem;">{hypo_prob*100:.0f}
            <span style="font-size:1.2rem; letter-spacing:0; color:#4a5568; font-weight:400;">%</span>
          </div>
          <div class="gauge-bar">
            <div style="width:{hypo_prob*100:.0f}%; height:100%; background:{risk_color}; border-radius:99px; transition: width 0.6s ease;"></div>
          </div>
          <span class="risk-badge" style="background:{risk_bg}; color:{risk_color};">{risk_label}</span>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown('<p class="section-title">Current snapshot</p>', unsafe_allow_html=True)

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(f'<div class="metric-mini"><div class="val">{glucose_lag_1}</div><div class="lbl">Current (mg/dL)</div></div>', unsafe_allow_html=True)
    with m2:
        trend = glucose_lag_1 - glucose_lag_3
        arrow = "↑" if trend > 0 else ("↓" if trend < 0 else "→")
        st.markdown(f'<div class="metric-mini"><div class="val">{arrow} {abs(trend):.0f}</div><div class="lbl">5-min trend</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric-mini"><div class="val">{insulin_bolus}U</div><div class="lbl">Bolus on board</div></div>', unsafe_allow_html=True)
    with m4:
        st.markdown(f'<div class="metric-mini"><div class="val">{carbs}g</div><div class="lbl">Active carbs</div></div>', unsafe_allow_html=True)

    if hypo_prob > 0.5:
        st.warning("⚠️ High hypoglycemia risk detected. Consider a small carbohydrate snack or reduced basal rate.")

else:
    st.markdown("""
    <div class="result-card" style="text-align:center; padding:3.5rem 2rem; border: 1px dashed #1e2130; background: #0d0f14;">
      <div style="font-family:'Space Mono',monospace; font-size:2.5rem; margin-bottom:1rem; color:#4f6ef7;">⬡</div>
      <div style="font-family:'Syne',sans-serif; font-size:1.15rem; font-weight:700; color:#e2e8f0; margin-bottom:0.5rem;">
        Enter values and run prediction
      </div>
      <div style="font-family:'Outfit',sans-serif; color:#4a5568; font-size:0.9rem;">
        Adjust patient inputs in the sidebar, then click <strong style="color:#6b7280;">Run prediction →</strong>
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("""
        <div style="background:#111318; border:1px solid #1e2130; border-radius:12px; padding:1.25rem 1.5rem;">
          <div style="font-family:'Space Mono',monospace; font-size:0.65rem; text-transform:uppercase; letter-spacing:0.12em; color:#4f6ef7; margin-bottom:0.5rem;">Regression model</div>
          <div style="font-family:'Syne',sans-serif; font-weight:600; color:#e2e8f0; margin-bottom:0.4rem;">Linear Regression</div>
          <div style="font-family:'Outfit',sans-serif; font-size:0.85rem; color:#6b7280; line-height:1.6;">Predicts exact glucose value 30 minutes ahead using lag features, insulin, carbs, vitals, and patient profile.</div>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown("""
        <div style="background:#111318; border:1px solid #1e2130; border-radius:12px; padding:1.25rem 1.5rem;">
          <div style="font-family:'Space Mono',monospace; font-size:0.65rem; text-transform:uppercase; letter-spacing:0.12em; color:#7c3aed; margin-bottom:0.5rem;">Classification model</div>
          <div style="font-family:'Syne',sans-serif; font-weight:600; color:#e2e8f0; margin-bottom:0.4rem;">Logistic Regression</div>
          <div style="font-family:'Outfit',sans-serif; font-size:0.85rem; color:#6b7280; line-height:1.6;">Predicts probability of hypoglycemia (glucose &lt; 80 mg/dL) within 30 minutes. Class-weighted 1:5 for sensitivity.</div>
        </div>
        """, unsafe_allow_html=True)
